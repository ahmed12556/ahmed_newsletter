<?php



\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'AhmedMage4_Newsletter',
    __DIR__
);
